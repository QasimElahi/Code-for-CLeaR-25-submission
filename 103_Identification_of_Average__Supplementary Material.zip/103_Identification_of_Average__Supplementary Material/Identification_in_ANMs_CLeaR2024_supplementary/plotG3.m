x =[10:10:100];

load("data_infer_20_n_d.mat")
options.x_axis = x;
options.marker = "-^"

options.color_line = [179, 63, 64]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)
grid on
xlabel("Sample Size")
ylabel("Proportion of DAGs of having sufficient data sets for Inference")

load("data_infer_20_lgn_d.mat")
options.x_axis = x;
options.marker = "-o"
options.color_line = [72, 161, 77]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)
grid on
xlabel("Sample Size")

load("data_infer_20_cnt_d.mat")
options.x_axis = x;
options.marker = "-square"
options.color_line = [01, 119, 179]./255 ;
options.color_area = options.color_line + (1-options.color_line)*2.3/4 ;
plot_areaerrorbar(e,options)

grid on
xlabel("Sample Size")
ylim([0 1])

box on
legend("","$d_{max}$ = $\mathcal{O}$(n)","","$d_{max}$ = $\mathcal{O}$(log(n))","","$d_{max}$ = $\mathcal{O}$(1)","Interpreter","latex")
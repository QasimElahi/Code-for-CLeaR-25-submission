function [A] = Learn_Acnestral_graph(Int,n,AA,varm,smp)


A = zeros(n,n);
S = [ decimalToBinaryVector(1:n,ceil(log2(n))+1)' ; ~ decimalToBinaryVector(1:n,ceil(log2(n))+1)' ];
S(:,Int)= 1;
C = combntns(1:1:n,2);
p=1;
for i =1:1:size(S,1)
  Si = S(i,:); 
  d =  rand_dag_sample(AA,n,Si,varm,smp);
    for j =1:1:size(C,1)
     if ((  Si(C(j,1)) + Si(C(j,2)) ) == 1  )
               p = indtest_new(d(:,C(j,1)),d(:,C(j,2)),[],[]) ; 
               src =  ( Si(C(j,1)) == 1 ) * C(j,1) + ( Si(C(j,2)) == 1 ) * C(j,2) ;
               dst = ( Si(C(j,1)) == 0 ) * C(j,1) + ( Si(C(j,2)) == 0 ) * C(j,2) ;
               if(p<= 0.000005) A(src,dst) =1; end

     end
 
   end

end
A = transitive_reduction(A);
end
function [out] = sample_dist_D(P,n)
mu = [ 0 0 0 1 3 7];
var = [0 0 0 0.5 1 1.5];
p1 = cumsum(P);
p1 = repmat(p1,n,1);
r = rand(n,1);
tmp = r>p1;
out1 = sum(tmp,2);
out = zeros(n,1);
out = (out1==3).*normrnd(1,0.5,n,1) + (out1==4).*normrnd(3,1,n,1)+(out1==5).*normrnd(7,1.5,n,1);

end